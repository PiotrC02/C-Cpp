#include <iostream>
#include "multiply.cpp"

using namespace std;

int main()
{

    cout << multiply(5,3) << endl; //odwolanie do int, nazwa udekorowania: Z8multiplyii
    cout << multiply(3.5f,5.3f) << endl; //odwolanie do float, nazwa udekorowania: Z8multiplyff

    return 0;
}

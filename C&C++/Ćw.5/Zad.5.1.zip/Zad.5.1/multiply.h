#pragma once

extern "C" //zmienna z modyfikatorem extern jest zewnetrzna
{
    int multiply(int x, int y);
}

float multiply(float x, float y);

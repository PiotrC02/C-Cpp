#include "multiply.h"

int multiply(int x, int y)
{
    return x*y;
}

float multiply(float x, float y)
{
    return x*y;
}

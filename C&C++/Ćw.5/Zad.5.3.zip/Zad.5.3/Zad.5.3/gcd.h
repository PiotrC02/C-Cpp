#pragma once

int iterGcd(int x, int y);
int recurGcd(int x, int y);

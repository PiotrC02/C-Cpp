#pragma once

int fibonacci(unsigned int n);

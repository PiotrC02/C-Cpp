#pragma once

void convertCase(char text[]);

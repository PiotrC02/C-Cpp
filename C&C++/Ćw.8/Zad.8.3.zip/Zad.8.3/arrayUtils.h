#pragma once

char * resizeArray(char * array, unsigned int newSize);

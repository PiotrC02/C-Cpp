#pragma once

#include <stdbool.h>

typedef bool (*Predicate)(int, int);

